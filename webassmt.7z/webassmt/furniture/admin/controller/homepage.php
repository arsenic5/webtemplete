<?php
	$pagetitle = "Fran's Furniture";
	$context = showtemplate('../view/homepage_template.php', []);
?>