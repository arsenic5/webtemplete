<?php
	require '../database/connect.php';
	require '../models/database_table.php';
	require '../function/showtemplate.php';


	if(isset($_GET['page'])){
		$page = $_GET['page'];
	}
	else {
		$page = 'homepage';
	}

	require '../controller/'.$page.'.php';
	$templateVariable = [
		'pagetitle' => $pagetitle,
		'context' => $context
	];

	$html = showtemplate ('../view/admin_layout.php', $templateVariable);
	echo $html;
?>