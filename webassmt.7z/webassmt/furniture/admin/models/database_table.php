<?php
	class DatabaseTable{
		public $pdo; public $table;
	}
?>