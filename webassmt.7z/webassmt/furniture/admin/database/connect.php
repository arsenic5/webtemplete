<?php
	$host = 'localhost'; $db = 'public'; $user = 'root'; $pass = '';
	$pdo = new PDO('mysql:dbname='.$db.';host='.$host , $user , $pass);
?>