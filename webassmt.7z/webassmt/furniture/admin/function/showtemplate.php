<?php
	function showtemplate($file, $templateVariable){
		extract($templateVariable);
		ob_start();
		require $file;
		$context = ob_get_clean();
		return $context;
	}

?>